#!/usr/bin/env python
# -*- coding: utf-8 -*-
__version__ = '20160202'

if __name__ == '__main__':
    print (__version__)
